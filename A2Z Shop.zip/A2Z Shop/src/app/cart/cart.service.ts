import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Cart } from './cart';

@Injectable({
  providedIn: 'root'
})

export class CartService {

  constructor(private httpClient: HttpClient) { }

  viewAllCartItems():Observable<Cart>{
    const baseUrl = "https://localhost:44381/api/cart"
    return this.httpClient.get<Cart>(baseUrl);
  }

  addToCart(cartItem):Observable<Cart>{
    const baseUrl = "https://localhost:44381/api/cart";   
    return this.httpClient.post<Cart>(baseUrl, cartItem);
  }
}
 