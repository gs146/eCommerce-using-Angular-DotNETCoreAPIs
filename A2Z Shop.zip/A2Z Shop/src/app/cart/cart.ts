export interface Cart
{
    productId: number, 
    quantity: number,
    status: string,
    email:string
}