export interface Product {
    productId: number,
    categoryId:number,
    name:string,
    description:string,
    // rating:number,
    price:number,
    quantity:number
    // productImg:string,
    // review:number   
}

