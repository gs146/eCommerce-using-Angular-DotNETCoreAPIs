import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from '../site-layout/category';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private httpClient: HttpClient) { }

  createProduct(productBody):Observable<Product>{
    const baseUrl = "https://localhost:44381/api/product";
    // var jsonString = JSON.stringify(productBody)
    // console.log("from service: ", productBody );
    
    return this.httpClient.post<Product>(baseUrl, productBody);
  }

  viewProduct(productId):Observable<Product>{
    const baseUrl = "https://localhost:44381/api/product/"+productId;
    return this.httpClient.get<Product>(baseUrl);
  }

  viewAllProduct():Observable<Product>{
    // const baseUrl = "http://localhost:3000/product/";
    const baseUrl = "https://localhost:44381/api/product"
    return this.httpClient.get<Product>(baseUrl);
  }

  searchCategoryProduct(categoryId):Observable<Product>{
  
    // const baseUrl = "http://localhost:3000/product?categoryId="+categoryId;
    const baseUrl = "https://localhost:44381/api/product/find/"+categoryId;
    return this.httpClient.get<Product>(baseUrl);
  }

  getCategory(){
    // const catUrl = "http://localhost:3000/category";
    const catUrl = "https://localhost:44381/product/category";
    return this.httpClient.get<Category>(catUrl);
  }

  updateProduct(productId, productBody):Observable<Product>{
    const baseUrl = "http://localhost:3000/product/"+productId;
    return this.httpClient.put<Product>(baseUrl, productBody);
  }

}
