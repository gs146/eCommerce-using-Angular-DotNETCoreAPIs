import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
  }

  addNewProduct(form){
    console.log(form.value);

    let newProduct ={
      productId:199,
      name:form.value.product_name,
      categoryId:Number(form.value.product_category),
      description:form.value.product_description,
      quantity:10,
      price:Number(form.value.product_price),
      // rating:form.value.product_rating,
      // productImg: "assets/sp.jpg",
      // review:form.value.product_reviews   
    };
    console.log(newProduct);
    this.productService.createProduct(newProduct).subscribe(data=>{
      console.log("subscribed:",data);
    })
  }
} 